"use strict";
exports.id = 168;
exports.ids = [168];
exports.modules = {

/***/ 3168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ DataSecurity_DataSecureScreen)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/assets/images/DataSecure-2.png
/* harmony default export */ const DataSecure_2 = ({"src":"/_next/static/media/DataSecure-2.42c9960a.png","height":405,"width":449,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAArUlEQVR42mP49///v39A4v/3n/8+fvnz//9fiAADRPTtlz9n7/1aevTfzVf/f/79D5RjABIvPv5+e+7C4cV3p7e/vrHu/Nvnn4GCIImdh9/PyL5W5fnkTc3k/xOLfx06+Aco8fPH37K6j8UzvhfP/P5o7o6/3S0bJtz5+Res4+DRz5M2fupc8a190ssNvVe27vrx9+9fkMS3719PX3h67uKL42eev/vy6z8I/AMA5vyRC31rtp8AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/PagesComponent/DataSecurity/DataSecureScreen.js




const DataSecureScreen = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: " text-center mt-5 comman-heading",
                        children: "Data Privacy"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cst-hr-for-process mb-3"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "Data-border",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center mt-5 comman-heading",
                        children: "OverView Of Our NDA"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cst-hr-for-process mb-3"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            display: "flex"
                        },
                        className: "text-center row",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-lg-6 data-li",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "key-clauses comman-heading",
                                        children: "Key Clauses of an NDA"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        class: "list-group text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit,"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: " sed do eiusmod tempor incididunt ut labore et dolore "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "magna aliqua. Ut enim ad minim veniam, quis nostrud "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "exercitation ullamco laboris nisi ut aliquip ex ea "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "commodo consequat. Duis aute irure dolor in "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "reprehenderit in voluptate velit esse cillum dolore"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-lg-6",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: DataSecure_2,
                                    style: {
                                        height: "300px",
                                        width: "300px"
                                    }
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center mt-5 comman-heading",
                        children: "How We Keep Your App Idea Safe"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cst-hr-for-process mb-3"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "Data-border",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center mt-5 comman-heading",
                        children: "Security Measures to Prevent Data Breach"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cst-hr-for-process mb-3"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "Data-border",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            display: "flex"
                        },
                        className: "text-center row mt-5",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-lg-6 data-li",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "key-clauses",
                                        style: {
                                            fontWeight: "bold"
                                        },
                                        children: "General Security"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        class: "list-group text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit,"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: " sed do eiusmod tempor incididunt ut labore et dolore "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "magna aliqua. Ut enim ad minim veniam, quis nostrud "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "exercitation ullamco laboris nisi ut aliquip ex ea "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "commodo consequat. Duis aute irure dolor in "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "reprehenderit in voluptate velit esse cillum dolore"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-lg-6 data-li",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "key-clauses",
                                        style: {
                                            fontWeight: "bold"
                                        },
                                        children: "Network Security"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        class: "list-group text-start",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit,"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: " sed do eiusmod tempor incididunt ut labore et dolore "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "magna aliqua. Ut enim ad minim veniam, quis nostrud "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "exercitation ullamco laboris nisi ut aliquip ex ea "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "commodo consequat. Duis aute irure dolor in "
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: "reprehenderit in voluptate velit esse cillum dolore"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center mt-5 comman-heading",
                        children: "Operational Security"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cst-hr-for-process mb-3"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "Data-border mb-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const DataSecurity_DataSecureScreen = (DataSecureScreen);


/***/ })

};
;