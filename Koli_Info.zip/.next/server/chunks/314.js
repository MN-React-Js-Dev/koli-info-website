"use strict";
exports.id = 314;
exports.ids = [314];
exports.modules = {

/***/ 2084:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/android1.ee88afa1.png","height":92,"width":92,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAgVBMVEX79v779v349Pvv8/bv8fbv8fXo7PDn7PDX3eLW3eKEk6BgdoeEk6BedIaFlKD59fz28/ru8vXt8vXt8PTn7O/m7O/W3eHW5uXW3eG039KEzbiDzbdsyq6LlaOKlKInwZslwZtVbH7w9Pfq8PLo7fDP5eHO5eHY3uLB4dmEk6Bhd4kn37QMAAAAInRSTlMAAAAAAAAAAAAAAABAQEFCQkJCQkNDQ/39/f39/f39/f39//9MygAAAEhJREFUeNoFQAUWQDAA/bqbBRMLFvc/oIe69efl+xrFZig1a45s0ceulxTR4IRwAxCP33O/Y4xkVpyrKUFFLGOWlGi6IGXomh/E+QWHQKcnKAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 9621:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cross-platform1.3afd8f4c.png","height":92,"width":92,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/ElEQVR42gVAvS5DURz/nY/ee5y2F5VSiXQhJNbGU1g6mryEmGwmD2BogogH6E5sRhaR2JoaLBJXSO899+t8/IVNHj4nhQoHAEpwxhlDCJ6UbvgsObfHMtPhcD6wWxyAbwhUB2BFYPgt93Z3dCIDwbAWRz4vfZVaFieSVE8IzymTt6GRggVyzmGpL1h3s8UpYhQsQVcicieiz64ff764FhsNEbK8Ch2leE01mmULn/lX/muimzJT04HUxXZH86Fq29TT+3P1hzcqOvx03D27f5pdwpl6NRGmhTLNjVmsxRGSWEYSAEb76x/ju3yEq4UFYnMxjY66RbvnCvfyDwYddmnGbbKdAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 4214:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ipad.a7b7e4a5.png","height":85,"width":85,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5klEQVR42h2NMUvEQBSE5+2+bFZFgol4zYlioWAjgo3nbxB78S+Kf8HOzlioV9hpZcBrktzFJPue6w3TzDB8Q8/v890i4VIMTzuBSghwzlFi6Wt7k89ZD45yfnrcm1cGr8UhtsKApQy42PeT2SQtWN5Ksadn4+wqc5fW4l8UKcu2HT8+F4ERA4hIRdA83IONwcb1zbqDCLEOA2ANQtOgvb1DCsBXFZAkwDiCyTlEinK+g/ylhCGCyTJQXWscKTMnRkR47H5BxycQBfquQ4id5WgoFv3QV3VTT7vVan2deg9V/fbe//wBBktj8PvBi3oAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6685:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/userInterface1.bf36f6a3.png","height":92,"width":92,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABC0lEQVR42hXJP0vDQBiA8ffeuxjbFGJtsaUIRQTBCoKTi5OzLlpcxNVv4CYuXV0csvkJ/Ax+ACddFCTSRQnRprHmn7nkenfG3/g85E0G61nCT50bc8tPTNYVgCXl0dlFPAKAMaNIdjknG0mQn+z1FHy0NCTeHJpzNmw34AClLjK3zL6336P8aOZqZ/9F4qAQTKL1C8RhdlhMBp8qsC87MKv3yJM0MF4TNK9liprGJmPtFTeP0+7OEmCzZoFJFyHNSz0uUyRap7hMGuGU84kdmXKhZFojKAJK8JyWiHjFoDJ9Dv2H1U7d+qHAUFHJQYw8/7Ba9wT+HV/TfjI8T4nRCkWVPPEFr/3bO3jEP7sbeHOGJn5jAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 7461:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ux1.71047343.png","height":92,"width":92,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABE0lEQVR4nAEIAff+AVBOkyzw3fQBl2jIXBAM9k/7/gUA7fsisTGwPKJg/97cAZmz1PoqJRoDBP34AvT4/AAeDQEAA+/kAObv/fw+neoxAbfN5P/L/vcA2/0I/XYWBAEs110AAAC8/eUHmwXl4+qLAbTN5f32EAcC9PwBADAMCAAi+uIAAAH//ufu/AIOznLaAY6ixf8nJBv+Af38Avb6/AD9CAYA9xIN//X3+QE146jSATEsa/EoD/kO6PUE/L/QFAMtUfoA02pc+jsABAc28OWqAcaachQxEbGyw9w5OX3LNwBjLOMAOzUKAPT9D9A3d++9AbuDQwALBfEJDAoRhBYO60r8/AcAGwnJtgAbAHu4xGT4t8V8qR8W2bAAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ })

};
;