"use strict";
exports.id = 248;
exports.ids = [248];
exports.modules = {

/***/ 8248:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Testimonial_TestiHeroSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/assets/images/TestiHero-2.png
/* harmony default export */ const TestiHero_2 = ({"src":"/_next/static/media/TestiHero-2.94984943.png","height":320,"width":320,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA4ElEQVR42mP4v1eLkQEJ/FpnrAai/6+RZ4EL/tsiKZRd0sq5uaOk+N9G3W//N2r4MSCD/+vEq36stE6dUlDU8XuV/K43i5wC/29QqP29zkiPAQQOt7VkHWxpzfWP7g5l8JlQXBtcbvNpQXDv/12y3Awg4B05Ics5bFJxamKjt3LctG2/J8tUPW/Wz4NbsTffNOZdB0MKg9NsOwadrIUXFsyOPTSlLxmuYGOGmcfXbgZPhrDZNgwMHqX/r+y3+X/+oBVcQUxgqVRmWJmYs3W4CAODmuKmhUskd63dCGQzMAAAd05U23A50YkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/PagesComponent/Testimonial/TestiHeroSection.js




const TestiHeroSection = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "testi-hero-image ",
            style: {
                backgroundColor: "#E3E3FF"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-lg-6 mt-5 text-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "hero-sec-header",
                                    children: "TESTIMONIAL"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "para-for-hero",
                                    children: "We are a company that offers design and develop services for you from initial sketches to the final construction."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-lg-6 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: TestiHero_2,
                                className: "img-fluid testi-image"
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const Testimonial_TestiHeroSection = (TestiHeroSection);


/***/ })

};
;