"use strict";
exports.id = 578;
exports.ids = [578];
exports.modules = {

/***/ 7680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/profile.034d2c3a.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAABAElEQVR42iXPvUrDUBgG4PecxqRSiAYdRIVKQSHqJKhEr8B78AJyI70Bp7gojjoIgpNLF9szBRyKIg6CIIrGBkvJz/n7BPvcwcMA4P78JCRVJi6jCLCQFoIxxACe2OC0G5K1fUYm+Pz6BnGO5cUAmpCD8UNOWibcquB3lMmbQYruxTXS4VA2jAzI6MSBriMyClUl3f2DI+xuv+Oud+tura2g4bUix6gaVBdoyjGakxKVLrDXacNUEwAMXBdjkf2M0Ht4kcqWWGg5WJqblWQJWtXC8XQZX4nH/qV4DtZfc/hND+nbh3t27Oc7G+2YYSrc7KwmWVFHpbHwvRkxT9V/8w8HKX3s22kbKgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1578:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_HomePage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/PagesComponent/HomePage/HeroSection.js


const HeroSection = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "hero-section hero-image mb-5",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-lg-6 mt-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "hero-sec-header",
                                children: "Ideas Into Reality"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "para-for-hero",
                                children: "We are a company that offers design and develop services for you from initial sketches to the final construction."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                class: "btn contact-us-btn",
                                type: "submit",
                                children: "Contact Us"
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const HomePage_HeroSection = (HeroSection);

;// CONCATENATED MODULE: ./src/assets/images/IdesignImage.png
/* harmony default export */ const IdesignImage = ({"src":"/_next/static/media/IdesignImage.7f243de3.png","height":238,"width":293,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAoUlEQVR42gGWAGn/AOjn552liL+6rMzLzsbFxujp6+zu8OXm6QDq6uvQqIvNs6C8wMa6u7/f3d3SwrrEs6sA4d/f5dbN5tfS2Njf4OTq3MGzoWpPmmZEAOHh4vHr6dnDvsfJz93h5tm6spZXM5ZdNgDs7e396N7m08qIi5GtrK/ZztDNtrClh3sA5d3Z27Siv5mHj3Nvwaak2tXZ0c3Sx8PGrSlspA78QNgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./src/assets/images/grid2image.png
/* harmony default export */ const grid2image = ({"src":"/_next/static/media/grid2image.eea69dcc.png","height":238,"width":293,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAoUlEQVR42gGWAGn/ACIkKAAAAGdwc97q69Lb2cLQ08PKz/z5+wAUFR4OGA5TW17Y5efP29ilsr+OmJ57imEAEREZKCwoPkNDwM7QwcW/kX5wWmdjZHNMAAAACgAAAAAAAJCXnKCmrXByfXN2hNXU0wBOTVampaeWl5qdqrjL1+Tc5e6ElqbP0dQAn5yd5Oflra6sjJWhvcnXtb/Mv8HG/Pz8RrBPtpPvbgsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/PagesComponent/HomePage/OurPortfolio.js





const OurPortfolio = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "our-portfolio ",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "main-div-for-portfolio pb-5",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    class: "container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            class: "text-center pt-5 comman-heading",
                            children: "Our Portfolio"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "cst-hr-for-process mb-5"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: IdesignImage,
                                        className: "img-fluid"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-3",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-3 pt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                children: "Mobile App"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                children: [
                                                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
                                                    " "
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: IdesignImage,
                                        className: "img-fluid"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-3",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-3 pt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                children: "Mobile App"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                children: [
                                                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
                                                    " "
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-3",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-3 pt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                children: "Web Development"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                children: [
                                                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
                                                    " "
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: IdesignImage,
                                        className: "img-fluid"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-3",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "p-3 pt-5",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                children: "Mobile App"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                children: [
                                                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et",
                                                    " "
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: IdesignImage,
                                        className: "img-fluid"
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const HomePage_OurPortfolio = (OurPortfolio);

;// CONCATENATED MODULE: ./src/assets/images/circleimage (1).png
/* harmony default export */ const circleimage_1_ = ({"src":"/_next/static/media/circleimage (1).7472adf0.png","height":551,"width":597,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAlklEQVR42j2OOQ7CMBREff8TcAEKeloOQEMQQWYLJFgE7NDgeF8/BgmmnTd6g2KMSsnrTXfE4oPa7kVKCQCQlDKEAL/QwW+wAMjIexcSzNZmsjTTlSnd7qToYNB3mC9UdIPEDQGIpHfzxYisdYU6P3jHRE9ZgfBRsadGnHPv/458Z66q+cdRzOPIWyKaVhdtVb/KTwB4A7pznRT1AWDoAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/assets/images/circleimage (2).png
/* harmony default export */ const circleimage_2_ = ({"src":"/_next/static/media/circleimage (2).2ee6ab2e.png","height":549,"width":601,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAqElEQVR42iWOywqCQBiF53mD3qVo1SqibRtBgqJN0EJIvLTSwIWXATUsxxkZ59L8aZ3VuSzOh7TWrO9Zng9ZRh7xKwg+WgMAopT+HVUaKOdF0XjeNAghDJiL7Tur/XuJoK7aOGYYIzCGimG2OOEocg4b1jKeZ5VlISmlEHJtX+fb4+58B4A2DFlZIkKIUmrMA0ziGD9v7vQxtqTr2jRlSdL4fu26+sfyBZeQlqXr5YADAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/assets/images/circleimage (3).png
/* harmony default export */ const circleimage_3_ = ({"src":"/_next/static/media/circleimage (3).652eab98.png","height":551,"width":597,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAnUlEQVR42jVOzQrCMBjr+18FH0O8iAcPnoZM5txUVJiyn852qGx2XWFtLZ/fUHMIgYQkxFqrVMdZw8rmdGBxWDjnAIBIKZ17o1K9Rq64CNf5YBhjMGEMpOe9EjWA3kUMCwiaRvVJcvVXnjdfdtrR7DmbHInWQ8PC80fjaUU56igoKv4iQgjchz9utA789LfRtqKkj/Ryjzf5Nsi+rz4SIZpc5cE9cwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/assets/images/circleimage (4).png
/* harmony default export */ const circleimage_4_ = ({"src":"/_next/static/media/circleimage (4).38ec2381.png","height":549,"width":595,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAoElEQVR42jVOywrCMBDMj/sfCp704knpyUNB72JFVBBstQ/E2lJL82hpkk3XRHBOuzPMgwCAEIKXWVvETXquH0djDCISzrkBsNeADn2d1/eDE7SS2uBi5U9nc2/rqCY5tZ+c4GB6jaOxP1lu1rvQCjazDDwipbQP7/Q1Lm7xs1PAsouwDkopaI1/sCKtwr3tI0opShl9J+wV2UlVFMBvyxefFpohtXnRCwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/assets/images/OurProcessBg.png
/* harmony default export */ const OurProcessBg = ({"src":"/_next/static/media/OurProcessBg.9c984298.png","height":408,"width":1400,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACBAMAAACXuoDeAAAAD1BMVEX///////7+/v77+/729/5lsSXgAAAAEklEQVR42mNgYlISZnBQUlQEAANVAN4ZDZPwAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":2});
;// CONCATENATED MODULE: ./src/PagesComponent/HomePage/OurProcessSection.js








const OurProcessSection = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "our-process-section mb-5",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "comman-heading text-center",
                        children: "Our Process"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cst-hr-for-process mb-5"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "cst-our-process",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "circle first-circle"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "text-center mt-3 mx-3",
                                            children: "Planning "
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "circle second-circle mx-3"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "text-center mt-3",
                                            children: "Designing "
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "circle third-circle mx-3"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "text-center mt-3",
                                            children: "Development "
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "circle fourth-circle mx-3"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "text-center mt-3",
                                            children: "Testing "
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "circle fifth-circle mx-3"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "text-center mt-3",
                                            children: "Delivery "
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const HomePage_OurProcessSection = (OurProcessSection);

;// CONCATENATED MODULE: ./src/assets/images/wireframe1.png
/* harmony default export */ const wireframe1 = ({"src":"/_next/static/media/wireframe1.a3a7ae57.png","height":78,"width":78,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA1ElEQVR42kXDQS4EQRyF8ff+VdWtRxoLRCYmkYiDuAI3srFzELGylggrJxCskJEgMkxKMrp01dM7X74ft09jNmD4vw8RkOCA7Kc/vAfQDMqAAyFoBeZ+AUQ+vs4Pu4ytYOizwFKEu7h6fnVzvbdRJfm21lkLIGXCm+CMWB/NPm/z9GQZzdiyKGcoF08sMTEBAqzu54v+iLRjC054+6ZdvtMeZnSORJdSvejSC8lnk8DggIOJsDkSsgASvqn8WNLE58K4tqR2f0fqM5gKQeirCn4XQPMHI/RfzkAkQo0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: ./src/assets/images/design1.png
var design1 = __webpack_require__(3545);
// EXTERNAL MODULE: ./src/assets/images/web-development1.png
var web_development1 = __webpack_require__(51);
// EXTERNAL MODULE: ./src/assets/images/applications1.png
var applications1 = __webpack_require__(8391);
// EXTERNAL MODULE: ./src/assets/images/onDemCrsl-1.png
var onDemCrsl_1 = __webpack_require__(4586);
// EXTERNAL MODULE: ./src/assets/images/onDemCrsl-2.png
var onDemCrsl_2 = __webpack_require__(1577);
// EXTERNAL MODULE: ./src/assets/images/onDemCrsl-3.png
var onDemCrsl_3 = __webpack_require__(195);
// EXTERNAL MODULE: ./src/Redux/module/getOurServiceAction.js
var getOurServiceAction = __webpack_require__(4204);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./src/PagesComponent/HomePage/OurServices.js













const OurServices = ()=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    const [ourService, setOurService] = (0,external_react_.useState)();
    const carousel = (0,external_react_.useRef)(null);
    const dataSelector = (0,external_react_redux_.useSelector)((state)=>state?.getOurServices);
    const handleLeftClick = (e)=>{
        e.preventDefault();
        carousel.current.scrollLeft -= carousel.current.offsetWidth;
    };
    const handleRightClick = (e)=>{
        e.preventDefault();
        carousel.current.scrollLeft += carousel.current.offsetWidth;
    };
    (0,external_react_.useEffect)(()=>{
        if (dataSelector != null) {
            setOurService(dataSelector?.ourServices?.data?.rows);
        }
    }, [
        dataSelector
    ]);
    (0,external_react_.useEffect)(()=>{
        dispatch((0,getOurServiceAction/* getAllOurServicesStart */.WC)());
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "our-services",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "wrap-our-service",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-center comman-heading text-white pt-5",
                            children: "Our Services"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "cst-hr-for-process mb-5"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "img-slide-box",
                                ref: carousel,
                                children: ourService?.map((data, index)=>{
                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-sm-4 mb-4",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "card p-5 cst-border-cls service-card",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: design1/* default */.Z,
                                                    alt: data?.title,
                                                    className: "mb-4 mt-4 img-fluid "
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                    children: data?.title
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: data?.description
                                                })
                                            ]
                                        })
                                    }, index);
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "buttons m-3 text-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: handleLeftClick,
                                    className: "m-3 p-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineLeft, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: handleRightClick,
                                    className: "m-3 p-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineRight, {})
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const HomePage_OurServices = (OurServices);

;// CONCATENATED MODULE: ./src/assets/images/mobile1.png
/* harmony default export */ const mobile1 = ({"src":"/_next/static/media/mobile1.2834d0fb.png","height":336,"width":570,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAiElEQVR42gF9AIL/AAEtAGJpaGlvd3x/iMLCzrm5xcHBy5OPlQBPWEtXVFtJTlRFUVyYmqPT09y7vcerrbsAiZCkTYK+Wmt6WmJgP0hNnZmbqJ6jt7S9ALy7x3Cf21uRzZKXp1hkcGhudbOQhrmUgwCopaywuNB1n9eUl6h1gpmEhpOVZlm2kYFmhEGTaD1xWwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/assets/images/mobile2.png
/* harmony default export */ const mobile2 = ({"src":"/_next/static/media/mobile2.23fcf72f.png","height":336,"width":570,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAiElEQVR42gF9AIL/AJSLh5qTj7SvrKKbmHlyb4mCf7Crp6ynowCSioaQiIS2sK2FfXpybm1NSUd0cG2moZ4AiH97mJCNi4N/bWppSEI/W1ZUAAAAgnx5AJePi42EgGpmZNra2r6+vSYeG1lUUqulogCOhYBkW1e4t7fW1NO2tbUAAACLhIGlnpo6PTz/F9saNgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/assets/images/skyBlueLeft.png
/* harmony default export */ const skyBlueLeft = ({"src":"/_next/static/media/skyBlueLeft.a57ee35e.png","height":220,"width":67,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAAIBAMAAAAhAzNxAAAAFVBMVEXq6v7p6f7p6f7p6f7p6f7q6v7p6f4fw8aUAAAABXRSTlMATFbR+8nUbPwAAAAWSURBVHjaY1BgSGQIZggBwmCGRAYFABKQAlG7rk/+AAAAAElFTkSuQmCC","blurWidth":2,"blurHeight":8});
// EXTERNAL MODULE: ./src/Redux/module/getOurBlogAction.js
var getOurBlogAction = __webpack_require__(6724);
;// CONCATENATED MODULE: ./src/PagesComponent/HomePage/OurTopBlogs.js










const OurTopBlogs = ()=>{
    const carousel = (0,external_react_.useRef)(null);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const [ourBlogs, setOurBlogs] = (0,external_react_.useState)();
    const data = (0,external_react_redux_.useSelector)((state)=>state?.getOurBlog);
    const handleLeftClick = (e)=>{
        e.preventDefault();
        carousel.current.scrollLeft -= carousel.current.offsetWidth;
    };
    const handleRightClick = (e)=>{
        e.preventDefault();
        carousel.current.scrollLeft += carousel.current.offsetWidth;
    };
    (0,external_react_.useEffect)(()=>{
        if (data != null) {
            setOurBlogs(data?.ourBlog?.data?.data);
        }
    }, [
        data
    ]);
    (0,external_react_.useEffect)(()=>{
        dispatch((0,getOurBlogAction/* getAllOurBlogStart */.LK)());
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "top-blogs",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: " text-center mt-5 bold-font",
                        children: "Our Top Blogs"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cst-hr-for-process mb-5"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "img-slide-box",
                            ref: carousel,
                            children: ourBlogs?.rows?.map((data, index)=>{
                                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-6",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        class: "card m-3 service-card",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                class: "date-cst",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    class: "day",
                                                    children: data?.created_at
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: mobile1,
                                                className: "card-img-top"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                class: "card-body",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                        children: data?.title
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        class: "card-text",
                                                        children: data?.description
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }, index);
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "buttons m-3 text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: handleLeftClick,
                                className: "m-3 p-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineLeft, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: handleRightClick,
                                className: "m-3 p-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineRight, {})
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const HomePage_OurTopBlogs = (OurTopBlogs);

;// CONCATENATED MODULE: ./src/PagesComponent/HomePage/ScheduleAnAppointment.js


const ScheduleAnAppointment = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "mt-5 mt-5",
            style: {
                "background": "#3F689F"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-sm-6",
                            children: " "
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-sm-6",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-5 mb-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                            className: "text-white mb-3 schedule-appointment",
                                            children: "Schedule an appointment"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "hr-cst mb-3"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    class: "form-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            class: "form-control",
                                                            placeholder: "Name"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    class: "form-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "email",
                                                            class: "form-control",
                                                            id: "exampleInputEmail1",
                                                            placeholder: "Email"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    class: "form-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            class: "form-control",
                                                            placeholder: "Phone"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    class: "form-group",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "text",
                                                            class: "form-control",
                                                            placeholder: " "
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    class: "btn contact-us-btn mb-5",
                                    type: "submit",
                                    children: "Send Now"
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const HomePage_ScheduleAnAppointment = (ScheduleAnAppointment);

;// CONCATENATED MODULE: ./src/assets/images/teamoffice.png
/* harmony default export */ const teamoffice = ({"src":"/_next/static/media/teamoffice.af9b21ca.png","height":516,"width":600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAtUlEQVR42mPw9HSKjQpMjA6Z1N04sbsxNNDbQF+PAQLiIoKn9rY2VJXmZaS01pVXFGX5eDgyVNbUTJ8+fe7smUsWL6irqysvLeloaezr7mDobG1as2zJhN7eFUuXLpo7Z2pf78TuzpryMobkpPhgP5/E5KScnNzSgqz40EATS9vMtBSGzrbGkvys2OgIUSFuoH1dLQ0zJvauWDiHYXJfe3tTbX5WWkSIv621eX1l6bxp/T2tdQAYIUge3SGbgwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/PagesComponent/HomePage/WhyChooseKOLIinfotech.js




const WhyChooseKOLIinfotech = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "mb-5 mt-5 why-choos",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-sm-6",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "comman-heading",
                                    children: "Why Choose"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "comman-heading",
                                    children: "KOLI infotech"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hr-cst mb-3"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-sm-6",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: teamoffice,
                                className: "img-fluid"
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const HomePage_WhyChooseKOLIinfotech = (WhyChooseKOLIinfotech);

;// CONCATENATED MODULE: ./src/assets/Logo/footerlogo2.png
/* harmony default export */ const footerlogo2 = ({"src":"/_next/static/media/footerlogo2.05b3464e.png","height":132,"width":160,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAtklEQVR42mNgMClk7Ju7kZEBBGxKlyeUTl7JAAXpVdMYGdSC6pkZQMCyuCu1cur/hWt2/U+pmNrLAASL1+5mZsipm8nKAAShuX0dIMm8xln/GaxLuhiAQCe4joUBGWTXzehhcCrvZkABbuVxTG7lRgzOpSoMDN4qPB7l9vwe5TYMrmVWQKzDwOBW5gDEUYxu5T7K/tU2bO7l/gyu5T5Ajb5ABeEMDDDgVcfO4FHLzAAC7u1MMGEAjmkzvKt4P3QAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: ./src/assets/Logo/SVGlogo.svg
var SVGlogo = __webpack_require__(3031);
;// CONCATENATED MODULE: ./src/commonComponent/Footer.js





const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-6 cst-footer-logo",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: SVGlogo/* default */.Z,
                            className: "mt-5 cst-footer-logo"
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const commonComponent_Footer = (Footer);

// EXTERNAL MODULE: ./src/commonComponent/Header.js + 1 modules
var Header = __webpack_require__(5796);
// EXTERNAL MODULE: ./src/assets/images/profile.png
var profile = __webpack_require__(7680);
;// CONCATENATED MODULE: ./src/assets/images/blueRight.png
/* harmony default export */ const blueRight = ({"src":"/_next/static/media/blueRight.d1123108.png","height":220,"width":64,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAAICAYAAADTLS5CAAAALklEQVR42mPQTPnJAMReIMIViP8zaCX/OKcFYmgm//itBRX5jSHlCsRgBgh7AQDXoiMBypiuWQAAAABJRU5ErkJggg==","blurWidth":2,"blurHeight":8});
// EXTERNAL MODULE: ./src/Redux/module/getOurClientsAction.js
var getOurClientsAction = __webpack_require__(488);
;// CONCATENATED MODULE: ./src/PagesComponent/HomePage/OurValuableClients.js







// import Profile from '../../assets/images/profile.png'
const OurValuableClients = ()=>{
    const [clients, setClients] = (0,external_react_.useState)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const dataSelector = (0,external_react_redux_.useSelector)((state)=>state?.getOurClients);
    (0,external_react_.useEffect)(()=>{
        dispatch((0,getOurClientsAction/* getAllOurClientStart */.tA)());
    }, []);
    (0,external_react_.useEffect)(()=>{
        if (dataSelector != null) {
            setClients(dataSelector?.ourClients?.data?.rows);
        }
    }, [
        dataSelector
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            className: "our-valuable-clients mb-5 mt-5",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-center mt-5 comman-heading",
                        children: "Our Valuable Clients"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "cst-hr-for-process mb-5"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        class: "container-fluid",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            class: "row",
                            children: clients?.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    class: "col-md-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "client-box ratangale-one mt-3",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: profile/* default */.Z
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "t-dark",
                                                    children: item.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: item.review
                                                })
                                            ]
                                        })
                                    })
                                }, index))
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const HomePage_OurValuableClients = (OurValuableClients);

;// CONCATENATED MODULE: ./src/pages/HomePage.js












const HomePage = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_HeroSection, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_OurProcessSection, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_OurServices, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_OurPortfolio, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_WhyChooseKOLIinfotech, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_OurValuableClients, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_OurTopBlogs, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(HomePage_ScheduleAnAppointment, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(commonComponent_Footer, {})
        ]
    });
};
/* harmony default export */ const pages_HomePage = (HomePage);


/***/ })

};
;