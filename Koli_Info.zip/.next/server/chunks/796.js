"use strict";
exports.id = 796;
exports.ids = [796];
exports.modules = {

/***/ 3031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/SVGlogo.397f516a.svg","height":140,"width":199,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 5796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ commonComponent_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/assets/Logo/bluelogo.png
/* harmony default export */ const bluelogo = ({"src":"/_next/static/media/bluelogo.1eca1e66.png","height":80,"width":96,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAQAAACfUMTVAAAAY0lEQVR42iWNMQ5AQBBFR4ibaBQKJZFQCzWNYygkriDEGRScS+IU3li7r3mZSf7/8npi4GS39kR9o5WHg8k9AqOZi5tN7GVhZBGHDqREGmtJQaaJUGlPTU6rNQ2dC4T81XbvA3DpMGt1xGUyAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/assets/Logo/SVGlogo.svg
var SVGlogo = __webpack_require__(3031);
;// CONCATENATED MODULE: ./src/commonComponent/Header.js






const Header = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "row",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        className: "navbar navbar-expand-lg bg-body-tertiary",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "container-fluid cst-nav p-3 header",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    className: "nav-link active",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: SVGlogo/* default */.Z,
                                        alt: bluelogo,
                                        className: "img-fluid"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "navbar-toggler",
                                    type: "button",
                                    "data-bs-toggle": "collapse",
                                    "data-bs-target": "#navbarSupportedContent",
                                    "aria-controls": "navbarSupportedContent",
                                    "aria-expanded": "false",
                                    "aria-label": "Toggle navigation",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "navbar-toggler-icon"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "collapse navbar-collapse",
                                    id: "navbarSupportedContent",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                            className: "navbar-nav me-auto mb-2 mb-lg-0",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    className: "nav-link active",
                                                    "aria-current": "page",
                                                    href: "#"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                            className: "d-flex",
                                            role: "search",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                className: "navbar-nav me-auto  mb-lg-0 header-ul",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "nav-link active header-links",
                                                            "aria-current": "page",
                                                            href: "/aboutCompany",
                                                            children: "Company "
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "nav-link active header-links",
                                                            "aria-current": "page",
                                                            href: "/mobiAppDevelopment",
                                                            children: "Services "
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "nav-link active header-links",
                                                            "aria-current": "page",
                                                            href: "/solutionOnDemand",
                                                            children: "Solutions "
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "nav-link active header-links",
                                                            "aria-current": "page",
                                                            href: "/portfolio",
                                                            children: "Our Portfolio "
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "nav-link active header-links",
                                                            "aria-current": "page",
                                                            href: "/career",
                                                            children: "Career "
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        className: "nav-item",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                            className: "btn contact-us-btn header-links",
                                                            type: "submit",
                                                            href: "/contactUs",
                                                            children: "Contact Us"
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const commonComponent_Header = (Header);


/***/ })

};
;