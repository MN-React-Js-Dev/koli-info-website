"use strict";
exports.id = 703;
exports.ids = [703];
exports.modules = {

/***/ 5624:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DO": () => (/* binding */ GETALL_OUR_BLOG_SUCCESS),
/* harmony export */   "Gt": () => (/* binding */ GETALL_OUR_CLIENT_SUCCESS),
/* harmony export */   "LV": () => (/* binding */ GETALL_OUR_PRODUCT_START),
/* harmony export */   "Ry": () => (/* binding */ GETALL_OUR_PRODUCT_SUCCESS),
/* harmony export */   "Uo": () => (/* binding */ GETALL_OUR_SERVICES_ERROR),
/* harmony export */   "Xn": () => (/* binding */ GETALL_OUR_SERVICES_START),
/* harmony export */   "_S": () => (/* binding */ GETALL_OUR_BLOG_ERROR),
/* harmony export */   "ai": () => (/* binding */ GETALL_OUR_CLIENT_START),
/* harmony export */   "lY": () => (/* binding */ GETALL_OUR_BLOG_START),
/* harmony export */   "sf": () => (/* binding */ GETALL_OUR_SERVICES_SUCCESS),
/* harmony export */   "sw": () => (/* binding */ GETALL_OUR_CLIENT_ERROR),
/* harmony export */   "w4": () => (/* binding */ GETALL_OUR_PRODUCT_ERROR)
/* harmony export */ });
const GETALL_OUR_SERVICES_START = "GETALL_OUR_SERVICES_START";
const GETALL_OUR_SERVICES_SUCCESS = "GETALL_OUR_SERVICES_SUCCESS";
const GETALL_OUR_SERVICES_ERROR = "GETALL_OUR_SERVICES_ERROR";
const GETALL_OUR_PRODUCT_START = "GETALL_OUR_PRODUCT_START";
const GETALL_OUR_PRODUCT_SUCCESS = "GETALL_OUR_PRODUCT_SUCCESS";
const GETALL_OUR_PRODUCT_ERROR = "GETALL_OUR_PRODUCT_ERROR";
const GETALL_OUR_BLOG_START = "GETALL_OUR_BLOG_START";
const GETALL_OUR_BLOG_SUCCESS = "GETALL_OUR_BLOG_SUCCESS";
const GETALL_OUR_BLOG_ERROR = "GETALL_OUR_BLOG_ERROR";
const GETALL_OUR_CLIENT_START = "GETALL_OUR_CLIENT_START";
const GETALL_OUR_CLIENT_SUCCESS = "GETALL_OUR_CLIENT_SUCCESS";
const GETALL_OUR_CLIENT_ERROR = "GETALL_OUR_CLIENT_ERROR";


/***/ }),

/***/ 6724:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LK": () => (/* binding */ getAllOurBlogStart),
/* harmony export */   "WU": () => (/* binding */ getAllOurBlogSuccess),
/* harmony export */   "hd": () => (/* binding */ getAllOurBlogError)
/* harmony export */ });
/* harmony import */ var _actionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5624);

const getAllOurBlogStart = ()=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_BLOG_START */ .lY
    });
const getAllOurBlogSuccess = (Blog)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_BLOG_SUCCESS */ .DO,
        payload: Blog
    });
const getAllOurBlogError = (error)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_BLOG_ERROR */ ._S,
        payload: error
    });


/***/ }),

/***/ 488:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fi": () => (/* binding */ getAllOurClientSuccess),
/* harmony export */   "tA": () => (/* binding */ getAllOurClientStart),
/* harmony export */   "z": () => (/* binding */ getAllOurClientError)
/* harmony export */ });
/* harmony import */ var _actionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5624);

const getAllOurClientStart = ()=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_CLIENT_START */ .ai
    });
const getAllOurClientSuccess = (clients)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_CLIENT_SUCCESS */ .Gt,
        payload: clients
    });
const getAllOurClientError = (error)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_CLIENT_ERROR */ .sw,
        payload: error
    });


/***/ }),

/***/ 4204:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WC": () => (/* binding */ getAllOurServicesStart),
/* harmony export */   "eE": () => (/* binding */ getAllOurServicesError),
/* harmony export */   "x4": () => (/* binding */ getAllOurServicesSuccess)
/* harmony export */ });
/* harmony import */ var _actionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5624);

const getAllOurServicesStart = ()=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_SERVICES_START */ .Xn
    });
const getAllOurServicesSuccess = (services)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_SERVICES_SUCCESS */ .sf,
        payload: services
    });
const getAllOurServicesError = (error)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_SERVICES_ERROR */ .Uo,
        payload: error
    });


/***/ })

};
;