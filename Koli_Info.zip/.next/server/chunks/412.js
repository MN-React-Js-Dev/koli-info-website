"use strict";
exports.id = 412;
exports.ids = [412];
exports.modules = {

/***/ 4061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OK": () => (/* binding */ getAllOurProductSuccess),
/* harmony export */   "cY": () => (/* binding */ getAllOurProductError),
/* harmony export */   "iS": () => (/* binding */ getAllOurProductStart)
/* harmony export */ });
/* harmony import */ var _actionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5624);

const getAllOurProductStart = ()=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_PRODUCT_START */ .LV
    });
const getAllOurProductSuccess = (Product)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_PRODUCT_SUCCESS */ .Ry,
        payload: Product
    });
const getAllOurProductError = (error)=>({
        type: _actionTypes__WEBPACK_IMPORTED_MODULE_0__/* .GETALL_OUR_PRODUCT_ERROR */ .w4,
        payload: error
    });


/***/ }),

/***/ 322:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Redux_rootReducer)
});

// EXTERNAL MODULE: external "redux"
var external_redux_ = __webpack_require__(6695);
// EXTERNAL MODULE: ./src/Redux/module/actionTypes.js
var actionTypes = __webpack_require__(5624);
;// CONCATENATED MODULE: ./src/Redux/reducer/getOurServiceReducer.js

const initialState = {
    ourServices: [],
    loading: false
};
const getAllOurServiceReducer = (state = initialState, action)=>{
    switch(action.type){
        case actionTypes/* GETALL_OUR_SERVICES_START */.Xn:
            return {
                ...state,
                loading: true
            };
        case actionTypes/* GETALL_OUR_SERVICES_SUCCESS */.sf:
            return {
                ...state,
                loading: true,
                ourServices: action.payload
            };
        case actionTypes/* GETALL_OUR_SERVICES_ERROR */.Uo:
            return {
                ...state,
                loading: false,
                error: action.payload
            };
        default:
            return state;
    }
};
/* harmony default export */ const getOurServiceReducer = (getAllOurServiceReducer);

;// CONCATENATED MODULE: ./src/Redux/reducer/getOurProductReducer.js

const getOurProductReducer_initialState = {
    ourProduct: [],
    loading: false
};
const getAllOurProductReducer = (state = getOurProductReducer_initialState, action)=>{
    switch(action.type){
        case actionTypes/* GETALL_OUR_PRODUCT_START */.LV:
            return {
                ...state,
                loading: true
            };
        case actionTypes/* GETALL_OUR_PRODUCT_SUCCESS */.Ry:
            return {
                ...state,
                loading: true,
                ourProduct: action.payload
            };
        case actionTypes/* GETALL_OUR_PRODUCT_ERROR */.w4:
            return {
                ...state,
                loading: false,
                error: action.payload
            };
        default:
            return state;
    }
};
/* harmony default export */ const getOurProductReducer = (getAllOurProductReducer);

;// CONCATENATED MODULE: ./src/Redux/reducer/getAllOurBlogReducer.js

const getAllOurBlogReducer_initialState = {
    ourBlog: [],
    loading: false
};
const getAllOurBlogReducer = (state = getAllOurBlogReducer_initialState, action)=>{
    switch(action.type){
        case actionTypes/* GETALL_OUR_BLOG_START */.lY:
            return {
                ...state,
                loading: true
            };
        case actionTypes/* GETALL_OUR_BLOG_SUCCESS */.DO:
            return {
                ...state,
                loading: true,
                ourBlog: action.payload
            };
        case actionTypes/* GETALL_OUR_BLOG_ERROR */._S:
            return {
                ...state,
                loading: false,
                error: action.payload
            };
        default:
            return state;
    }
};
/* harmony default export */ const reducer_getAllOurBlogReducer = (getAllOurBlogReducer);

;// CONCATENATED MODULE: ./src/Redux/reducer/getOurClientReducer.js

const getOurClientReducer_initialState = {
    ourClients: [],
    loading: false
};
const getAllOurClientReducer = (state = getOurClientReducer_initialState, action)=>{
    switch(action.type){
        case actionTypes/* GETALL_OUR_CLIENT_START */.ai:
            return {
                ...state,
                loading: true
            };
        case actionTypes/* GETALL_OUR_CLIENT_SUCCESS */.Gt:
            return {
                ...state,
                loading: true,
                ourClients: action.payload
            };
        case actionTypes/* GETALL_OUR_CLIENT_ERROR */.sw:
            return {
                ...state,
                loading: false,
                error: action.payload
            };
        default:
            return state;
    }
};
/* harmony default export */ const getOurClientReducer = (getAllOurClientReducer);

;// CONCATENATED MODULE: ./src/Redux/rootReducer.js
// import { combineReducers } from "redux";





const rootReducer = (0,external_redux_.combineReducers)({
    getOurServices: getOurServiceReducer,
    getOurProduct: getOurProductReducer,
    getOurBlog: reducer_getAllOurBlogReducer,
    getOurClients: getOurClientReducer
});
/* harmony default export */ const Redux_rootReducer = (rootReducer);


/***/ }),

/***/ 699:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ blogSaga)
/* harmony export */ });
/* unused harmony exports onGetALLBlogStartAsync, onGetAllBlog */
/* harmony import */ var _module_actionTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5624);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6477);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _module_getOurBlogAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6724);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_api__WEBPACK_IMPORTED_MODULE_1__]);
_services_api__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function* onGetALLBlogStartAsync() {
    try {
        const response = yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.call)(_services_api__WEBPACK_IMPORTED_MODULE_1__/* .getAllOurblogAPI */ .ZS);
        if (response.data.status == 200) {
            yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_module_getOurBlogAction__WEBPACK_IMPORTED_MODULE_2__/* .getAllOurBlogSuccess */ .WU)(response));
        }
    } catch (error) {
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_module_getOurBlogAction__WEBPACK_IMPORTED_MODULE_2__/* .getAllOurBlogError */ .hd)(error.response));
    }
}
function* onGetAllBlog() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.takeLatest)(_module_actionTypes__WEBPACK_IMPORTED_MODULE_3__/* .GETALL_OUR_BLOG_START */ .lY, onGetALLBlogStartAsync);
}
const blogSagas = [
    (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.fork)(onGetAllBlog)
];
function* blogSaga() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.all)([
        ...blogSagas
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6853:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ clientSaga)
/* harmony export */ });
/* harmony import */ var _module_actionTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5624);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6477);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _module_getOurClientsAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(488);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_api__WEBPACK_IMPORTED_MODULE_1__]);
_services_api__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function* onGetALLClientStartAsync() {
    try {
        const response = yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.call)(_services_api__WEBPACK_IMPORTED_MODULE_1__/* .getAllOurAllClientAPI */ .Ty);
        if (response.data.status == 200) {
            yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_module_getOurClientsAction__WEBPACK_IMPORTED_MODULE_2__/* .getAllOurClientSuccess */ .Fi)(response.data));
            console.log("client saga  successsssssss.........");
        }
    } catch (error) {
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_module_getOurClientsAction__WEBPACK_IMPORTED_MODULE_2__/* .getAllOurClientError */ .z)(error.response));
        console.log("client saga  errorrrrr.........");
    }
}
function* onGetAllClient() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.takeLatest)(_module_actionTypes__WEBPACK_IMPORTED_MODULE_3__/* .GETALL_OUR_CLIENT_START */ .ai, onGetALLClientStartAsync);
}
const clientsSagas = [
    (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.fork)(onGetAllClient)
];
function* clientSaga() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.all)([
        ...clientsSagas
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6436:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ productSaga)
/* harmony export */ });
/* unused harmony exports onGetALLProductStartAsync, onGetAllProduct */
/* harmony import */ var _module_actionTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5624);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6477);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _module_getOurProductAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4061);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_api__WEBPACK_IMPORTED_MODULE_1__]);
_services_api__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function* onGetALLProductStartAsync() {
    try {
        const response = yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.call)(_services_api__WEBPACK_IMPORTED_MODULE_1__/* .getAllOurProductAPI */ .ve);
        if (response.data.status == 200) {
            yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_module_getOurProductAction__WEBPACK_IMPORTED_MODULE_2__/* .getAllOurProductSuccess */ .OK)(response));
        }
    } catch (error) {
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_module_getOurProductAction__WEBPACK_IMPORTED_MODULE_2__/* .getAllOurProductError */ .cY)(error.response));
    }
}
function* onGetAllProduct() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.takeLatest)(_module_actionTypes__WEBPACK_IMPORTED_MODULE_3__/* .GETALL_OUR_PRODUCT_START */ .LV, onGetALLProductStartAsync);
}
const productsSagas = [
    (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.fork)(onGetAllProduct)
];
function* productSaga() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.all)([
        ...productsSagas
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9589:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ serviceSaga)
/* harmony export */ });
/* harmony import */ var _module_actionTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5624);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6477);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _module_getOurServiceAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4204);
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_api__WEBPACK_IMPORTED_MODULE_1__]);
_services_api__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function* onGetALLServicesStartAsync() {
    try {
        const response = yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.call)(_services_api__WEBPACK_IMPORTED_MODULE_1__/* .getAllOurServicesAPI */ .aO);
        if (response.data.status == 200) {
            yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_module_getOurServiceAction__WEBPACK_IMPORTED_MODULE_2__/* .getAllOurServicesSuccess */ .x4)(response.data));
        }
    } catch (error) {
        yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.put)((0,_module_getOurServiceAction__WEBPACK_IMPORTED_MODULE_2__/* .getAllOurServicesError */ .eE)(error.response));
    }
}
function* onGetAllServices() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.takeLatest)(_module_actionTypes__WEBPACK_IMPORTED_MODULE_3__/* .GETALL_OUR_SERVICES_START */ .Xn, onGetALLServicesStartAsync);
}
const servicesSagas = [
    (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.fork)(onGetAllServices)
];
function* serviceSaga() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.all)([
        ...servicesSagas
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 484:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ rootSaga)
/* harmony export */ });
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6477);
/* harmony import */ var redux_saga_effects__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _getAllOurServicesSaga__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9589);
/* harmony import */ var _getAllOurProductSaga__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6436);
/* harmony import */ var _getAllOurBlogSaga__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(699);
/* harmony import */ var _getAllOurClientSaga__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6853);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_getAllOurServicesSaga__WEBPACK_IMPORTED_MODULE_1__, _getAllOurProductSaga__WEBPACK_IMPORTED_MODULE_2__, _getAllOurBlogSaga__WEBPACK_IMPORTED_MODULE_3__, _getAllOurClientSaga__WEBPACK_IMPORTED_MODULE_4__]);
([_getAllOurServicesSaga__WEBPACK_IMPORTED_MODULE_1__, _getAllOurProductSaga__WEBPACK_IMPORTED_MODULE_2__, _getAllOurBlogSaga__WEBPACK_IMPORTED_MODULE_3__, _getAllOurClientSaga__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function* rootSaga() {
    yield (0,redux_saga_effects__WEBPACK_IMPORTED_MODULE_0__.all)([
        (0,_getAllOurServicesSaga__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(),
        (0,_getAllOurProductSaga__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP)(),
        (0,_getAllOurBlogSaga__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP)(),
        (0,_getAllOurClientSaga__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)()
    ]);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4104:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ty": () => (/* binding */ getAllOurAllClientAPI),
/* harmony export */   "ZS": () => (/* binding */ getAllOurblogAPI),
/* harmony export */   "aO": () => (/* binding */ getAllOurServicesAPI),
/* harmony export */   "ve": () => (/* binding */ getAllOurProductAPI)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const baseUrl = "http://192.168.0.135:3000/api/";
const getAllOurServicesAPI = async ()=>await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${baseUrl}` + "ourService/getAll-ourService");
const getAllOurProductAPI = async ()=>await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${baseUrl}` + "ourProduct/getAll-ourProduct");
const getAllOurblogAPI = async ()=>await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${baseUrl}` + "ourBlog/getAll-ourBlog");
const getAllOurAllClientAPI = async ()=>await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${baseUrl}` + "ourClient/getAll-ourClient");

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1412:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6695);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_saga__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5998);
/* harmony import */ var redux_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4634);
/* harmony import */ var redux_logger__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_logger__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(173);
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _rootReducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(322);
/* harmony import */ var _saga_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(484);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([redux_saga__WEBPACK_IMPORTED_MODULE_1__, _saga_index__WEBPACK_IMPORTED_MODULE_5__]);
([redux_saga__WEBPACK_IMPORTED_MODULE_1__, _saga_index__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const sagaMiddleware = (0,redux_saga__WEBPACK_IMPORTED_MODULE_1__["default"])();
const middlewares = [
    sagaMiddleware
];
if (false) {}
const store = (0,redux__WEBPACK_IMPORTED_MODULE_0__.createStore)(_rootReducer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, (0,redux_devtools_extension__WEBPACK_IMPORTED_MODULE_3__.composeWithDevTools)((0,redux__WEBPACK_IMPORTED_MODULE_0__.applyMiddleware)(...middlewares)));
sagaMiddleware.run(_saga_index__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (store);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;